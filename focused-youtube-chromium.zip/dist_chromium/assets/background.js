const e=typeof browser<"u"?browser:chrome;e.runtime.onInstalled.addListener(r=>{r.reason==="install"&&e.tabs.create({url:"welcome.html"})});
